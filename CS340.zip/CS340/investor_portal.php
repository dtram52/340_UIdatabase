<h3>Manage your investment Portfolio</h3>  

  <div class="container">
    <form method="post" action="search.php">
        <input type="hidden" name="submitted" value="true" />
        <legend>Please Enter Investor Title</legend>
        <div class="form-group">
          <label for="inputname">Title</label>
          <input type="text" name="title" class="form-control" id="inputname" placeholder="">
        </div>
        <button type="submit" class="btn btn-default">Submit</button>
    </form>